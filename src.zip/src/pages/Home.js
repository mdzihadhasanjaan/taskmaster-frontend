import React from 'react';
import { Link } from 'react-router-dom';
import '../styles.css';

function Home() {
  return (
    <div className="home-container">
      <h1 className="main-title">Welcome to TaskMaster</h1>
      <p className="subtitle">Organize your tasks, boost your productivity.</p>
      <div className="home-buttons">
        <Link to="/tasks">
          <button className="primary-button">Go to Tasks</button>
        </Link>
        <Link to="/login">
          <button className="secondary-button">Login</button>
        </Link>
      </div>
    </div>
  );
}

export default Home;
